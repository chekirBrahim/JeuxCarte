<?php 

class Carte extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function CarteRecup()
	{

		$this->load->model('carte_model');
		$carte= new Carte_model();
		
		$resultat_table=$carte->prendre();		
		$final_result=$carte->traitement($resultat_table);

		$jsontab=json_encode(['cards'=>$final_result['result'],'categoryOrder'=>$final_result['tabCategory'],'valueOrder'=>$final_result['TabValueOrder']]);
		$data = array('jsontab' => $jsontab);

		$this->load->view('welcome_message',$data);

	}

}