<?php 
   Class Carte_model extends CI_Model {
	
      Public function __construct() { 
         parent::__construct(); 
      } 

      Public function prendre(){

		      	$curl = curl_init('https://recrutement.local-trust.com/test/cards/57187b7c975adeb8520a283c'); 
				curl_setopt($curl, CURLOPT_FAILONERROR, true); 
				curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
				curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
				curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);   
				$result = curl_exec($curl); 
				$result=json_decode($result,true);		

				return $result;

		
      }

      Public function traitement($result){

		      	$TabData= array();
				$Tabt= array();
				$TabCards= array();
				$tmp1= array();

		      	foreach ($result as $key=>$value) {	

					if ($key=="data") {
					$TabData[]=$value;


				foreach ($TabData as $key1 => $value1) {
					$Tabt=$value1;

							foreach ($Tabt as $keyCards => $valueCards) {
								if ($keyCards=="cards") {
								$TabCards=$valueCards;
							}
							elseif ($keyCards=="categoryOrder") {
								$TabCategoryOrder[]=$valueCards;
							}
							elseif ($keyCards=="valueOrder") {
								$TabValueOrder[]=$valueCards;
							}
							}
					
					}
				
					}	

				}
				for ($j=0; $j <4 ; $j++) { 
   
					foreach($TabCategoryOrder as $keyCategory=> $category) {

							    for ($k=0; $k < 13; $k++) { 
									    foreach($TabValueOrder as $keyvaleur=> $valeur) {  
									 
									  $tmp = array();
									  $i=0;
											  foreach($TabCards as $keyCards=> $cards) {
											    
											    	 
													    if(($category[$j] == $TabCards[$i]['category']) && ($valeur[$k] == $TabCards[$i]['value'])) {
													    	
													    	 $tmp1[$i]['category'] = $TabCards[$i]['category'];
													    	 $tmp1[$i]['value'] = $TabCards[$i]['value'];
													    }  
											    
											     $i++;
											  }
									}
							}
					}

				}

$result = array_merge($tmp1);

//return $result;
return array("result"=>$result, "tabCategory"=>$TabCategoryOrder, "TabValueOrder"=>$TabValueOrder);

      }
		
   } 
?>